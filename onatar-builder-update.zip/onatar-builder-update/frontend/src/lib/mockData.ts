import type { ClassEntry, SpeciesEntry, BackgroundEntry, SpellEntry } from './types';

export const mockClasses: ClassEntry[] = [
  {
    id: "fighter",
    name: "Guerreiro",
    hitDie: 10,
    spellcaster: false,
    primaryAbility: ["STR", "DEX"],
    savingThrows: ["STR", "CON"],
    subclassLevel: 3,
    subClasses: [
      { id: "battle-master", name: "Battle Master", description: "Maneuvers de combate e dados de superioridade." },
      { id: "champion", name: "Champion", description: "Críticos melhorados e regeneração." },
      { id: "eldritch-knight", name: "Eldritch Knight", description: "Magia de evocação e abjuração." }
    ],
    features: [
      { name: "Second Wind", level: 1, description: "Regenera 1d10 + nível de HP como ação bónus." },
      { name: "Fighting Style", level: 1, description: "Escolhe um estilo de luta." },
      { name: "Action Surge", level: 2, description: "Uma ação extra no teu turno." },
      { name: "Weapon Mastery", level: 1, description: "Mastery com duas armas simples." }
    ],
    spellcasting: null,
    skillChoices: { count: 2, from: ["acrobatics", "animal-handling", "athletics", "history", "insight", "intimidation", "perception", "survival"] }
  },
  {
    id: "wizard",
    name: "Mago",
    hitDie: 6,
    spellcaster: true,
    primaryAbility: ["INT"],
    savingThrows: ["INT", "WIS"],
    subclassLevel: 3,
    subClasses: [
      { id: "abjuration", name: "Abjuration", description: "Proteção e barreiras mágicas." },
      { id: "evocation", name: "Evocation", description: "Magia destrutiva de dano." },
      { id: "divination", name: "Divination", description: "Vislumbres do futuro." }
    ],
    features: [
      { name: "Arcane Recovery", level: 1, description: "Recupera slots de magia num descanso curto." },
      { name: "Ritual Casting", level: 1, description: "Lança magias rituais do spellbook." },
      { name: "Spell Mastery", level: 5, description: "Lança magias de 1º e 2º nível a vontade." }
    ],
    spellcasting: {
      ability: "INT",
      preparedSpells: [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      knownSpells: false,
      slots: {
        "1": [2,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4],
        "2": [0,0,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3],
        "3": [0,0,0,0,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3]
      }
    },
    skillChoices: { count: 2, from: ["arcana", "history", "insight", "investigation", "medicine", "religion"] }
  }
];

export const mockSpecies: SpeciesEntry[] = [
  {
    id: "human",
    name: "Humano",
    description: "Versátil e ambicioso. Adaptam-se a qualquer papel.",
    traits: [
      { name: "Versatile", description: "+1 em todos os atributos." },
      { name: "Extra Language", description: "Aprende um idioma extra." }
    ],
    abilityBonuses: { STR: 1, DEX: 1, CON: 1, INT: 1, WIS: 1, CHA: 1 },
    size: "Medium",
    speed: 30,
    languages: ["Common"],
    variants: []
  },
  {
    id: "elf",
    name: "Elfo",
    description: "Gracioso e longevo. Conexão profunda com a natureza e a magia.",
    traits: [
      { name: "Darkvision", description: "Visão no escuro até 60 pés." },
      { name: "Trance", description: "Descansa em 4 horas em vez de 8." },
      { name: "Fey Ancestry", description: "Imunidade a encantamento, vantagem contra encantamento." }
    ],
    abilityBonuses: { DEX: 2 },
    size: "Medium",
    speed: 30,
    languages: ["Common", "Elvish"],
    variants: [
      { id: "high-elf", name: "High Elf", description: "+1 INT, cantrip extra." },
      { id: "wood-elf", name: "Wood Elf", description: "+1 WIS, speed 35, mask of the wild." }
    ]
  },
  {
    id: "dwarf",
    name: "Anão",
    description: "Resiliente e determinado. Mestres da pedra e do metal.",
    traits: [
      { name: "Darkvision", description: "Visão no escuro até 60 pés." },
      { name: "Dwarven Resilience", description: "Resistência a veneno." },
      { name: "Stonecunning", description: "Proficiência em história de pedra." }
    ],
    abilityBonuses: { CON: 2 },
    size: "Medium",
    speed: 25,
    languages: ["Common", "Dwarvish"],
    variants: [
      { id: "hill-dwarf", name: "Hill Dwarf", description: "+1 WIS, HP máximo +1/nível." },
      { id: "mountain-dwarf", name: "Mountain Dwarf", description: "+2 STR, proficiência em armadura leve e média." }
    ]
  },
  {
    id: "halfling",
    name: "Halfling",
    description: "Pequeno mas corajoso. Sorte natural e agilidade.",
    traits: [
      { name: "Lucky", description: "Relança 1s em ataques, testes ou salvaguardas." },
      { name: "Brave", description: "Vantagem contra medo." },
      { name: "Halfling Nimbleness", description: "Move-se através de criaturas maiores." }
    ],
    abilityBonuses: { DEX: 2 },
    size: "Small",
    speed: 25,
    languages: ["Common", "Halfling"],
    variants: [
      { id: "lightfoot", name: "Lightfoot", description: "+1 CHA, pode esconder-se atrás de criaturas maiores." },
      { id: "stout", name: "Stout", description: "+1 CON, resistência a veneno." }
    ]
  }
];

export const mockBackgrounds: BackgroundEntry[] = [
  {
    id: "acolyte",
    name: "Acólito",
    description: "Serviste num templo ou santuário. Conheces rituais e dogmas.",
    skillProficiencies: ["insight", "religion"],
    toolProficiencies: [],
    languages: [2],
    equipment: ["Holy symbol", "Prayer book", "5 sticks of incense", "Vestments", "Common clothes", "15 gp"],
    feature: { name: "Shelter of the Faithful", description: "Templos do teu deus fornecem abrigo e cuidados." }
  },
  {
    id: "sage",
    name: "Sábio",
    description: "Dedicaste a vida ao estudo. Acumulaste conhecimento em bibliotecas e academias.",
    skillProficiencies: ["arcana", "history"],
    toolProficiencies: [],
    languages: [2],
    equipment: ["Bottle of black ink", "Quill", "Small knife", "Letter from a dead colleague", "Common clothes", "10 gp"],
    feature: { name: "Researcher", description: "Sabes onde encontrar informação — bibliotecas, santuários, sábios." }
  },
  {
    id: "soldier",
    name: "Soldado",
    description: "Serviste num exército ou milícia. Sabes de hierarquia e combate.",
    skillProficiencies: ["athletics", "intimidation"],
    toolProficiencies: ["gaming-set"],
    languages: [0],
    equipment: ["Insignia of rank", "Trophy from a fallen enemy", "Bone dice or deck of cards", "Common clothes", "10 gp"],
    feature: { name: "Military Rank", description: "Soldados leais reconhecem a tua autoridade e prestam auxílio." }
  },
  {
    id: "criminal",
    name: "Criminoso",
    description: "Viveste à margem da lei. Conheces os submundos e os seus segredos.",
    skillProficiencies: ["deception", "stealth"],
    toolProficiencies: ["thieves-tools", "gaming-set"],
    languages: [0],
    equipment: ["Crowbar", "Dark common clothes with hood", "belt pouch", "15 gp"],
    feature: { name: "Criminal Contact", description: "Tens um contacto fiável nos submundos criminosos." }
  }
];

export const mockSpells: SpellEntry[] = [
  { id: "fire-bolt", name: "Fire Bolt", level: 0, school: "Evocation", description: "Ataque à distância de fogo. 1d10 de dano." },
  { id: "mage-hand", name: "Mage Hand", level: 0, school: "Conjuration", description: "Mão espectral que manipula objetos." },
  { id: "prestidigitation", name: "Prestidigitation", level: 0, school: "Transmutation", description: "Truques menores de magia." },
  { id: "shield", name: "Shield", level: 1, school: "Abjuration", description: "+5 AC até ao início do próximo turno." },
  { id: "magic-missile", name: "Magic Missile", level: 1, school: "Evocation", description: "3 dardos de força que acertam automaticamente." },
  { id: "burning-hands", name: "Burning Hands", level: 1, school: "Evocation", description: "Cone de fogo. 3d6 de dano." },
  { id: "charm-person", name: "Charm Person", level: 1, school: "Enchantment", description: "A criatura torna-se amigável." },
  { id: "detect-magic", name: "Detect Magic", level: 1, school: "Divination", description: "Sentes magia num raio de 30 pés." },
  { id: "misty-step", name: "Misty Step", level: 2, school: "Conjuration", description: "Teletransporta-te até 30 pés." },
  { id: "scorching-ray", name: "Scorching Ray", level: 2, school: "Evocation", description: "3 raios de fogo. 2d6 cada." }
];
