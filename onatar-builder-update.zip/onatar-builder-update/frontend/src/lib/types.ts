// Onatar shared types — aligned with backend BuildRequest / BuildResponse

export interface AbilityScores {
  STR: number;
  DEX: number;
  CON: number;
  INT: number;
  WIS: number;
  CHA: number;
}

export interface ClassEntry {
  id: string;
  name: string;
  hitDie: number;
  spellcaster: boolean;
  primaryAbility: string[];
  savingThrows: string[];
  subclassLevel?: number;
  subClasses?: SubClassEntry[];
  features?: ClassFeature[];
  spellcasting?: SpellcastingEntry | null;
  skillChoices?: { count: number; from: string[] };
}

export interface SubClassEntry {
  id: string;
  name: string;
  description: string;
}

export interface ClassFeature {
  name: string;
  level: number;
  description: string;
}

export interface SpellcastingEntry {
  ability: string;
  preparedSpells: number[];
  knownSpells: boolean;
  slots: Record<string, number[]>;
}

export interface SpeciesEntry {
  id: string;
  name: string;
  description: string;
  traits: TraitEntry[];
  abilityBonuses: Partial<AbilityScores>;
  size: string;
  speed: number;
  languages: string[];
  variants: SpeciesVariant[];
}

export interface SpeciesVariant {
  id: string;
  name: string;
  description: string;
}

export interface TraitEntry {
  name: string;
  description: string;
}

export interface BackgroundEntry {
  id: string;
  name: string;
  description: string;
  skillProficiencies: string[];
  toolProficiencies: string[];
  languages: number[];
  equipment: string[];
  feature: { name: string; description: string };
}

export interface SpellEntry {
  id: string;
  name: string;
  level: number;
  school: string;
  description: string;
}

export interface BuildRequest {
  name: string;
  classes: ClassReq[];
  backgroundId: string;
  speciesId: string;
  speciesVariant?: string;
  level: number;
  abilityScores: AbilityScores;
  abilityMethod: 'standard' | 'point-buy' | 'roll';
  skills: string[];
  spells: string[];
  feats: string[];
}

export interface ClassReq {
  id: string;
  level: number;
  subclassId?: string;
}

export interface BuildResponse {
  valid: boolean;
  errors?: string[];
  sheet?: CharacterSheet;
}

export interface CharacterSheet {
  name: string;
  level: number;
  hp: { max: number; current?: number };
  ac: number;
  proficiencyBonus: number;
  abilities: AbilityScores;
  savingThrows: Record<string, { proficient: boolean; modifier: number }>;
  skills: Record<string, { proficient: boolean; modifier: number }>;
  features: string[];
  spells?: string[];
  spellSlots?: Record<string, number>;
}

export interface ChoicePoint {
  type: 'subclass' | 'spell' | 'ability-improvement' | 'skill';
  classId?: string;
  level: number;
  name: string;
  description: string;
  options: Array<{ id: string; name: string; description: string }>;
}

export interface BuilderSnapshot {
  draft: BuildRequest;
  step: number;
  timestamp: number;
}
