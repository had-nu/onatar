import type {
  AbilityScores, BuildRequest, BuildResponse, CharacterSheet,
  ChoicePoint, BuilderSnapshot, ClassEntry, SpeciesEntry, BackgroundEntry, SpellEntry
} from './types';
import { mockClasses, mockSpecies, mockBackgrounds, mockSpells } from './mockData';

const defaultAbilities: AbilityScores = { STR: 10, DEX: 10, CON: 10, INT: 10, WIS: 10, CHA: 10 };

const initialDraft = (): BuildRequest => ({
  name: '',
  classes: [],
  backgroundId: '',
  speciesId: '',
  speciesVariant: undefined,
  level: 1,
  abilityScores: { ...defaultAbilities },
  abilityMethod: 'standard',
  skills: [],
  spells: [],
  feats: [],
});

// ─── State ─────────────────────────────────────────────────
export let draft = $state<BuildRequest>(initialDraft());
export let step = $state(0);
export let preview = $state<CharacterSheet | null>(null);
export let pendingChoices = $state<ChoicePoint[]>([]);
export let isLoading = $state(false);
export let error = $state<string | null>(null);

// Undo / redo
const MAX_HISTORY = 50;
let history = $state<BuilderSnapshot[]>([{ draft: initialDraft(), step: 0, timestamp: Date.now() }]);
let historyIndex = $state(0);

// Content cache (mock or fetched)
export let classes = $state<ClassEntry[]>(mockClasses);
export let species = $state<SpeciesEntry[]>(mockSpecies);
export let backgrounds = $state<BackgroundEntry[]>(mockBackgrounds);
export let spells = $state<SpellEntry[]>(mockSpells);

// ─── Derived ───────────────────────────────────────────────
export const totalLevel = $derived(draft.classes.reduce((s, c) => s + c.level, 0));
export const canUndo = $derived(historyIndex > 0);
export const canRedo = $derived(historyIndex < history.length - 1);
export const currentStepValid = $derived(validateStep(step));
export const classDef = $derived(classes.find(c => c.id === draft.classes[0]?.id));
export const speciesDef = $derived(species.find(s => s.id === draft.speciesId));
export const backgroundDef = $derived(backgrounds.find(b => b.id === draft.backgroundId));

// ─── Step validation ───────────────────────────────────────
function validateStep(s: number): boolean {
  switch (s) {
    case 0: return draft.classes.length > 0 && draft.classes[0].level >= 1;
    case 1: return !!draft.backgroundId;
    case 2: return !!draft.speciesId;
    case 3: return Object.values(draft.abilityScores).every(v => v >= 3 && v <= 20);
    case 4: return true; // equipment optional for now
    case 5: return !!draft.name && pendingChoices.length === 0;
    default: return false;
  }
}

// ─── History (undo/redo) ───────────────────────────────────
function pushHistory() {
  // Remove future history if we're not at the end
  if (historyIndex < history.length - 1) {
    history = history.slice(0, historyIndex + 1);
  }
  history.push({ draft: structuredClone(draft), step, timestamp: Date.now() });
  if (history.length > MAX_HISTORY) history.shift();
  else historyIndex++;
}

export function undo() {
  if (!canUndo) return;
  historyIndex--;
  const snap = history[historyIndex];
  draft = structuredClone(snap.draft);
  step = snap.step;
  requestPreview();
}

export function redo() {
  if (!canRedo) return;
  historyIndex++;
  const snap = history[historyIndex];
  draft = structuredClone(snap.draft);
  step = snap.step;
  requestPreview();
}

// ─── Draft mutations ───────────────────────────────────────
export function setStep(s: number) {
  if (s < 0 || s > 5) return;
  if (s > step && !currentStepValid) return; // block forward if invalid
  pushHistory();
  step = s;
}

export function nextStep() { setStep(step + 1); }
export function prevStep() { setStep(step - 1); }

export function setName(name: string) {
  draft.name = name;
  requestPreview();
}

export function selectClass(classId: string) {
  pushHistory();
  draft.classes = [{ id: classId, level: 1 }];
  draft.level = 1;
  requestPreview();
}

export function setSubclass(classId: string, subclassId: string) {
  pushHistory();
  draft.classes = draft.classes.map(c =>
    c.id === classId ? { ...c, subclassId } : c
  );
  requestPreview();
}

export function setBackground(id: string) {
  pushHistory();
  draft.backgroundId = id;
  // Auto-add background skills
  const bg = backgrounds.find(b => b.id === id);
  if (bg) {
    draft.skills = [...new Set([...draft.skills, ...bg.skillProficiencies])];
  }
  requestPreview();
}

export function setSpecies(id: string, variant?: string) {
  pushHistory();
  draft.speciesId = id;
  draft.speciesVariant = variant;
  // Apply ability bonuses
  const sp = species.find(s => s.id === id);
  if (sp) {
    const bonuses = sp.abilityBonuses;
    draft.abilityScores = {
      STR: defaultAbilities.STR + (bonuses.STR || 0),
      DEX: defaultAbilities.DEX + (bonuses.DEX || 0),
      CON: defaultAbilities.CON + (bonuses.CON || 0),
      INT: defaultAbilities.INT + (bonuses.INT || 0),
      WIS: defaultAbilities.WIS + (bonuses.WIS || 0),
      CHA: defaultAbilities.CHA + (bonuses.CHA || 0),
    };
  }
  requestPreview();
}

export function setAbilityScore(ability: keyof AbilityScores, value: number) {
  draft.abilityScores[ability] = Math.max(3, Math.min(20, value));
  requestPreview();
}

export function setAbilityMethod(method: BuildRequest['abilityMethod']) {
  pushHistory();
  draft.abilityMethod = method;
  // Reset scores based on method
  if (method === 'standard') {
    draft.abilityScores = { ...defaultAbilities };
  }
  requestPreview();
}

export function toggleSkill(skillId: string) {
  const set = new Set(draft.skills);
  if (set.has(skillId)) set.delete(skillId);
  else set.add(skillId);
  draft.skills = Array.from(set);
  requestPreview();
}

export function addSpell(spellId: string) {
  if (!draft.spells.includes(spellId)) {
    draft.spells = [...draft.spells, spellId];
    requestPreview();
  }
}

export function removeSpell(spellId: string) {
  draft.spells = draft.spells.filter(s => s !== spellId);
  requestPreview();
}

// ─── Debounced Preview ─────────────────────────────────────
let debounceTimer: ReturnType<typeof setTimeout> | null = null;

export function requestPreview() {
  if (debounceTimer) clearTimeout(debounceTimer);
  debounceTimer = setTimeout(async () => {
    await computePreview();
  }, 250);
}

async function computePreview() {
  // Minimal validation
  if (!draft.classes.length || !draft.backgroundId || !draft.speciesId) {
    preview = null;
    pendingChoices = [];
    return;
  }

  isLoading = true;
  error = null;

  try {
    // Try backend first
    const res = await fetch('/api/v1/build', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(draft),
    });

    if (res.ok) {
      const data: BuildResponse = await res.json();
      preview = data.sheet ?? null;
    } else {
      // Fallback to local computation
      preview = computeLocalPreview();
    }
  } catch {
    // Offline fallback
    preview = computeLocalPreview();
  }

  deriveChoices();
  isLoading = false;
}

// ─── Local Preview Computation (offline mode) ──────────────
function computeLocalPreview(): CharacterSheet {
  const cls = classDef;
  const lvl = totalLevel;
  const prof = Math.floor((lvl + 7) / 4);

  // HP: hit die + CON mod at level 1, then average + CON mod per level
  const conMod = Math.floor((draft.abilityScores.CON - 10) / 2);
  const hd = cls?.hitDie || 8;
  const hpMax = hd + conMod + (lvl - 1) * (Math.floor(hd / 2) + 1 + conMod);

  // AC: base 10 + DEX mod (simplified — no armor in MVP)
  const dexMod = Math.floor((draft.abilityScores.DEX - 10) / 2);
  const ac = 10 + dexMod;

  // Saving throws
  const saves: CharacterSheet['savingThrows'] = {};
  const abilities = ['STR', 'DEX', 'CON', 'INT', 'WIS', 'CHA'] as const;
  for (const ab of abilities) {
    const mod = Math.floor((draft.abilityScores[ab] - 10) / 2);
    const proficient = cls?.savingThrows.includes(ab) ?? false;
    saves[ab] = { proficient, modifier: mod + (proficient ? prof : 0) };
  }

  // Features
  const features: string[] = [];
  if (cls?.features) {
    for (const f of cls.features) {
      if (f.level <= lvl) features.push(f.name);
    }
  }
  if (speciesDef?.traits) {
    for (const t of speciesDef.traits) features.push(t.name);
  }
  if (backgroundDef?.feature) features.push(backgroundDef.feature.name);

  // Spell slots (simplified full caster progression)
  const spellSlots: Record<string, number> = {};
  if (cls?.spellcaster && cls.spellcasting) {
    const slots = cls.spellcasting.slots;
    for (const [level, arr] of Object.entries(slots)) {
      spellSlots[level] = arr[Math.min(lvl, 20) - 1] || 0;
    }
  }

  return {
    name: draft.name || 'Sem nome',
    level: lvl,
    hp: { max: Math.max(1, hpMax) },
    ac: Math.max(10, ac),
    proficiencyBonus: prof,
    abilities: { ...draft.abilityScores },
    savingThrows: saves,
    skills: {}, // simplified
    features,
    spells: draft.spells,
    spellSlots,
  };
}

// ─── Derive Pending Choices ────────────────────────────────
function deriveChoices() {
  const choices: ChoicePoint[] = [];
  const lvl = totalLevel;

  for (const cls of draft.classes) {
    const def = classes.find(c => c.id === cls.id);
    if (!def) continue;

    // Subclass choice
    if (def.subclassLevel && lvl >= def.subclassLevel && !cls.subclassId) {
      choices.push({
        type: 'subclass',
        classId: cls.id,
        level: def.subclassLevel,
        name: 'Escolher Subclasse',
        description: `Seleciona uma subclasse para ${def.name}`,
        options: (def.subClasses ?? []).map(sc => ({
          id: sc.id, name: sc.name, description: sc.description
        })),
      });
    }

    // Skill proficiencies (if not fully chosen)
    if (def.skillChoices) {
      const chosen = draft.skills.filter(s => def.skillChoices!.from.includes(s)).length;
      const remaining = def.skillChoices.count - chosen;
      if (remaining > 0) {
        choices.push({
          type: 'skill',
          classId: cls.id,
          level: 1,
          name: 'Proficiências de Skill',
          description: `Escolhe ${remaining} skill(s) de ${def.name}`,
          options: def.skillChoices.from
            .filter(s => !draft.skills.includes(s))
            .map(s => ({ id: s, name: s, description: '' })),
        });
      }
    }

    // Spell preparation (simplified)
    if (def.spellcaster && def.spellcasting?.preparedSpells) {
      const maxPrepared = def.spellcasting.preparedSpells[lvl - 1] || 0;
      const current = draft.spells.length;
      if (current < maxPrepared) {
        choices.push({
          type: 'spell',
          classId: cls.id,
          level: lvl,
          name: 'Preparar Magias',
          description: `Escolhe ${maxPrepared - current} magia(s) preparada(s)`,
          options: spells
            .filter(s => s.level <= 1 && !draft.spells.includes(s.id))
            .map(s => ({ id: s.id, name: s.name, description: s.description })),
        });
      }
    }
  }

  // ASI at levels 4, 8, 12, 16, 19
  if (lvl >= 4 && lvl % 4 === 0) {
    choices.push({
      type: 'ability-improvement',
      level: lvl,
      name: 'Melhoria de Atributo',
      description: 'Aumenta um atributo em +2 ou dois em +1, ou escolhe um feat.',
      options: [],
    });
  }

  pendingChoices = choices;
}

// ─── Save / Reset ──────────────────────────────────────────
export async function saveCharacter(): Promise<boolean> {
  if (!draft.name) {
    error = 'O personagem precisa de um nome.';
    return false;
  }
  if (pendingChoices.length > 0) {
    error = 'Há escolhas pendentes.';
    return false;
  }

  const payload = {
    request: { ...draft },
    sheet: preview,
  };

  try {
    const res = await fetch('/api/v1/characters', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error('Save failed');

    // Also save to localStorage as fallback
    const existing = JSON.parse(localStorage.getItem('onatar-characters') || '[]');
    existing.push(payload);
    localStorage.setItem('onatar-characters', JSON.stringify(existing));

    return true;
  } catch {
    // Fallback: save locally
    const existing = JSON.parse(localStorage.getItem('onatar-characters') || '[]');
    existing.push(payload);
    localStorage.setItem('onatar-characters', JSON.stringify(existing));
    return true;
  }
}

export function resetBuilder() {
  pushHistory();
  draft = initialDraft();
  step = 0;
  preview = null;
  pendingChoices = [];
}

export function loadFromCharacter(character: any) {
  draft = {
    name: character.name || '',
    classes: (character.classes || []).map((c: any) => ({
      id: c.id, level: c.level, subclassId: c.subclassId
    })),
    backgroundId: character.backgroundId || '',
    speciesId: character.speciesId || '',
    speciesVariant: character.speciesVariant,
    level: character.level || 1,
    abilityScores: character.abilities || { ...defaultAbilities },
    abilityMethod: character.abilityMethod || 'standard',
    skills: character.skills || [],
    spells: character.spells || [],
    feats: character.feats || [],
  };
  step = 0;
  requestPreview();
}
