# Onatar Builder Update — Arcanum Fusion

## O que está incluído

### Frontend (Svelte 5)
- **Landing page** com estética Arcanum (header gradiente, cards flutuantes, stats bar)
- **Builder wizard** em 6 steps com layout de duas colunas
- **Preview sidebar** em tempo real (HP, AC, Prof, atributos, features, spell slots)
- **Undo/redo** com histórico de 50 snapshots
- **Offline mode** — calcula preview localmente se o backend não responder
- **Componentes UI reutilizáveis**: Card, Button, Tag

### Mock Data
- 2 classes (Guerreiro, Mago) com subclasses e features
- 4 espécies (Humano, Elfo, Anão, Halfling) com variantes
- 4 backgrounds (Acólito, Sábio, Soldado, Criminoso)
- 10 spells (cantrips + nível 1-2)

## Estrutura de ficheiros

```
frontend/src/lib/
├── types.ts                    # Tipos TypeScript partilhados
├── builder.svelte.ts           # Store central (runes Svelte 5)
├── mockData.ts                 # Dados mock para desenvolvimento offline
├── ui/
│   ├── Card.svelte             # Variantes: default, elevated, selected, interactive
│   ├── Button.svelte           # Variantes: primary, secondary, outline, ghost, danger
│   └── Tag.svelte              # Variantes: default, primary, gold, green, blue
├── builder-steps/
│   ├── ClassStep.svelte        # Cards de classe + selector de subclass
│   ├── BackgroundStep.svelte   # Cards de background + equipamento
│   ├── SpeciesStep.svelte      # Cards de espécie + variantes
│   ├── AbilitiesStep.svelte    # Tabs (standard/point-buy/roll) + pool chips + slots
│   ├── EquipmentStep.svelte    # Lista de equipamento do background
│   └── ReviewStep.svelte       # Nome, pending choices, summary, save
├── components/
│   ├── StepsBar.svelte         # Chrome fixo com estados active/done/pending
│   └── PreviewSidebar.svelte   # Pré-visualização ao vivo da ficha
└── views/
    ├── Builder.svelte          # Layout duas colunas (content + preview sidebar)
    └── Landing.svelte          # Homepage redesenhada (estética Arcanum)

mockups/data/
├── classes.json
├── species.json
├── backgrounds.json
└── spells.json
```

## Como integrar no Onatar existente

### 1. Copiar ficheiros
```bash
# Copiar tudo para o teu repo
cp -r onatar-builder-update/frontend/src/lib/* /path/to/onatar/frontend/src/lib/
cp -r onatar-builder-update/mockups/* /path/to/onatar/mockups/
```

### 2. Atualizar app.css
Adicionar as variáveis CSS do tema Arcanum no topo do ficheiro:
```css
:root {
  --on-bg-root: #0d0d12;
  --on-bg-surface: #14141a;
  --on-bg-elevated: #1a1a24;
  --on-bg-hover: #24243d;
  --on-border: #2a1f1f;
  --on-border-light: #3d2a2a;
  --on-red: #c50009;
  --on-red-hover: #a00008;
  --on-red-glow: rgba(197, 0, 9, 0.15);
  --on-gold: #c9a94e;
  --on-gold-dim: #a8882e;
  --on-green: #00b87a;
  --on-blue: #5b8def;
  --on-text: #e8e0d8;
  --on-text-muted: #9a8e86;
  --on-text-dim: #6b5f57;
}
```

### 3. Substituir views
- Substituir `Landing.svelte` pela nova versão
- Substituir `Builder.svelte` pela nova versão
- Manter `Characters.svelte` e `CharacterView.svelte` do original

### 4. Atualizar App.svelte
Garantir que as rotas apontam para as novas views:
```svelte
{#if $route === '/'}<Landing />{/if}
{#if $route === '/builder'}<Builder />{/if}
```

## Funcionamento do builder

### Store (`builder.svelte.ts`)
O store usa **Svelte 5 runes** (`$state`, `$derived`) em vez de stores reativos tradicionais.

**Estado principal:**
- `draft` — BuildRequest com todos os dados da personagem em construção
- `step` — Índice do step atual (0-5)
- `preview` — CharacterSheet calculada pelo backend ou localmente
- `pendingChoices` — Escolhas pendentes derivadas da preview
- `history` — Array de snapshots para undo/redo (máx 50)

**Ações principais:**
- `selectClass(id)`, `setSubclass(cid, sid)`, `setBackground(id)`, `setSpecies(id, variant?)`
- `setAbilityScore(ab, val)`, `setAbilityMethod(method)`
- `toggleSkill(id)`, `addSpell(id)`, `removeSpell(id)`
- `undo()`, `redo()`, `nextStep()`, `prevStep()`, `saveCharacter()`

### Preview debounced
A cada mutação do draft, `requestPreview()` agenda um cálculo com debounce de 250ms:
1. Tenta `POST /api/v1/build` no backend Go
2. Se falhar → calcula localmente com `computeLocalPreview()`
3. Após preview → `deriveChoices()` popula pendingChoices

### Undo/Redo
Cada ação significativa (seleção de classe, background, espécie, método de abilities)
pusha um snapshot para o histórico. Undo/redo navegam neste histórico e restauram
tanto o draft como o step.

### Validação por step
- Step 0 (Classe): precisa de classe selecionada com nível >= 1
- Step 1 (Background): precisa de backgroundId
- Step 2 (Espécie): precisa de speciesId
- Step 3 (Atributos): todos os scores entre 3-20
- Step 4 (Equipamento): sempre válido (MVP)
- Step 5 (Revisão): nome preenchido + zero pending choices

## Notas de design (Arcanum → Onatar)

| Elemento | Implementação |
|---|---|
| Fundo | `#0d0d12` root, gradientes `#14141a` → `#1a1a24` para cards |
| Header | Gradient escuro + borda inferior carmesim 3px + sombra |
| Cards | Borda vinho `#2a1f1f`, hover elevação + borda vermelha + sombra |
| Selected | Borda ouro + glow dourado + checkmark ✓ |
| Stats | Cards dourados (`#c9a94e`) para HP/AC/Prof |
| Warnings | Fundo translúcido carmesim, texto `#ff6b6b` |
| Tags | Variantes coloridas com fundo translúcido |

## Estado de desenvolvimento

| Componente | Estado |
|---|---|
| Store + types | ✅ Completo |
| Landing page | ✅ Completo |
| StepsBar | ✅ Completo |
| ClassStep | ✅ Completo (cards + subclass) |
| BackgroundStep | ✅ Completo (cards + feature detail) |
| SpeciesStep | ✅ Completo (cards + variants) |
| AbilitiesStep | ✅ Completo (3 métodos + pool + slots) |
| EquipmentStep | ✅ Completo (lista do background) |
| ReviewStep | ✅ Completo (name + choices + summary + save) |
| PreviewSidebar | ✅ Completo (stats + abilities + features + warnings) |
| Button/Card/Tag | ✅ Completo |
| Mock data | ✅ Completo |

## Próximos passos sugeridos
1. Testar o fluxo completo com `npm run dev`
2. Ajustar o E2E Playwright para os novos seletores
3. Adicionar animações de transição entre steps
4. Implementar gestão de equipamento detalhada
5. Polir a ficha de personagem (`CharacterView.svelte`)
